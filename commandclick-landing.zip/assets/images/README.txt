INSTRUÇÕES PARA ADICIONAR A LOGO:

1. Salve a imagem da logo do Command Click como "command-click-logo.png"
2. Coloque o arquivo nesta pasta: /home/user/workspace/assets/images/
3. A logo será carregada automaticamente na landing page

Formato recomendado: PNG com fundo transparente
Dimensões recomendadas: 800x267px (proporção 3:1)
