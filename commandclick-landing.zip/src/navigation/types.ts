export type RootStackParamList = {
  Home: undefined;
  Form: undefined;
  ThankYou: undefined;
};
